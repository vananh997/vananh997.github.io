Thank you for using Foundation: Design Resources.
We hope this template will help you to create something incredible!

Free fonts used in design:
• Work Sans https://fonts.google.com/specimen/Work+Sans

You can purchase HTML / CSS version on our website: 
https://niceverynice.com/foundation-landing-template/

All illustrations were made by amazing team at Icons8:
https://icons8.com/ouch

---
Check out more products: https://niceverynice.com
Brought you by Nice, Very Nice.